function [impact,isterminal,direction] = checkImpact(~,X)
%CHECKIMPACT checks if any impact has been made, and tells of which kind

rM=1737100;         %(m) moon radius
rE=6371000;         %(m) earth radius

xM=X(1);
yM=X(2);
xS=X(3);
yS=X(4);

sM=[xM yM]'; %Earth-Moon CoM distance
sS=[xS yS]'; %Earth-Sat CoM distance
sS2M=sS-sM;  %Sat-Moon CoM distance

impact=0;
if norm(sS)<=rE %sat w/ Earth
    impact=1;
end
if norm(sS2M)<=rM %sat w/ Moon
    impact=2;
end
if norm(sM)<=rE+rM %moon w/Earth (Hey, you gotta check you know?)
    impact=3;
end

isterminal=1;
direction=1;
end

