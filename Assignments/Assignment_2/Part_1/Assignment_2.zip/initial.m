%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Author: Connie Childs
%Created: Feb 5, 2018
%This program finds the best way to recover Apollo 13 in aspects of lowest
%   deltav possible and/or fastest return time.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear variables

choice = menu('Minimize Time or Fuel?','Time','Fuel');
animate = menu('Animate?','Yes','No');


G=6.67408*10^-11;
mM=7.34767309e22;   %(kg) moon mass
mE=5.97219e24;      %(kg) earth mass
mS=28833;           %(kg) spacecraft mass
rM=1737100;         %(m) moon radius
rE=6371000;         %(m) earth radius

%% initial locations
dEM=384403000;  %(m) earth-moon distance
thetaM=42.5;    %(degrees) angle between earth-moon

dES=338000000;  %(m) earth-spacecraft distance
thetaS=50;      %(degrees) angle between earth-spacecraft

locM=dEM*[cosd(thetaM) sind(thetaM)]'; %(m) location of moon
locS=dES*[cosd(thetaS) sind(thetaS)]'; %(m)location of spacecraft
locE=[0 0]';                           %(m) location of earth

%% initial velocities
vM=sqrt((G*mE^2)/((mE+mM)*dEM));        %(m/s) speed of moon
velM=vM*[-sind(thetaM) cosd(thetaM)]';  %(m/s) velocity of moon

vS=1000;                                %(m/s) speed of spacecraft
velS=vS*[cosd(thetaS) sind(thetaS)]';   %(m/s) velocity of spacecraft

velE=[0 0]';                            %(m/s) velocity of earth

%guessing (works best if initial guess is already near final answer)
vMag=input('------------------------\nGive an initial velocity magnitude (m/s): ');              %(m/s) spacecraft deltav magnitude
if abs(vMag)>100
    error('Velocity magnitude is out of range');
end
vAng=input('------------------------\nSet an angle (degrees): ');             %(degree) spacecraft deltav magnitude
x0=[vMag;vAng];

% Set options 
options = optimset('Display','iter');

X=zeros(8,1);
X(1:2)=locM;
X(3:4)=locS;
X(5:6)=velM;
X(7:8)=velS;

x = fminsearch(@(x)optimize(x,X,choice),x0,options);

velS=velS+x(1)*[cosd(x(2)) sind(x(2))]'; %adjust spacecraft's initial velocity accordingly

%time constraints
ti=0; 
tf=10; %days
tf=tf*86400; %convert to seconds

X=zeros(8,1);
X(1:2)=locM;  %filling X vector slots
X(3:4)=locS;
X(5:6)=velM;
X(7:8)=velS;

options = odeset('Events',@checkImpact,'RelTol', 1e-8);

%% run ode45
[t,Y]=ode45(@trajectory,[ti tf],X,options);
switch choice
    case 1
        type='time';
    case 2
        type='fuel';
end
fprintf('Initial Guess:\n%.4f m/s\n%.4f�\n',vMag,vAng);
fprintf('\nTo save on %s:\n%.4f m/s\n%.4f�\n\n',type,x(1),x(2));
if choice == 1
    fprintf('Travel time:\n%.4f hours\n\n',t(end)/60/60);
end
if (x(1)<50 || t(end)<24*60*60)
    disp('WARNING! ANSWERS MAY BE INCORRECT!')
end
if animate==1
%% animation

figure(1) %generating figure

%coloring bodies bodies
colorMoon=[1/3 1/3 1/3];
colorSat=[1 0 0];
colorEarth=[0 0 1];

%preparing animation
h1 = animatedline('color',colorMoon);
h2 = animatedline('color',colorSat);

%graph cosmetics
hold on; grid on; grid minor;
title('Trajectories');
xlabel('meters');
ylabel('meters');

%scaling and orgin defining
M=max(max(abs(Y(:,1:4))));
if M>dEM*3 %making sure scaling doesn't blow up
    M=dEM*3;
end
axis([-M M -M M]); %set square frame
axis equal
plot(M,M,'.k','MarkerSize',.001); %corner frame nodes
plot(-M,-M,'.k','MarkerSize',.001);
plot(M,-M,'.k','MarkerSize',.001);
plot(-M,M,'.k','MarkerSize',.001);

%sizing Earth and Moon to scale
tSize=linspace(0,1); %parameterization vector
yM=rM*sin(2*pi.*tSize); %scaling moon
xM=rM*cos(2*pi.*tSize);
xE=rE*sin(2*pi.*tSize); %scaling earth
yE=rE*cos(2*pi.*tSize);
plot(xE,yE,'linewidth',3,'color',colorEarth); %plotting earth

%animating
for i=1:length(t)
    addpoints(h1,Y(i,1),Y(i,2)); %moon path
    moon=plot(xM+Y(i,1),yM+Y(i,2),'linewidth',2,'color',colorMoon); %moon body
    addpoints(h2,Y(i,3),Y(i,4)); %sat path
    sat=plot(Y(i,3),Y(i,4),'o','MarkerSize',1,'MarkerFaceColor',colorSat,'color',colorSat); %sat body
    drawnow; %<- self explainitory
    if i~=length(t) %delete bodies unless last frame
        delete(moon);
        delete(sat);
    end
end
end