function f = optimize(x,X,choice)
vS=1000;                                %(m/s) speed of spacecraft
thetaS=50;                              
velS=vS*[cosd(thetaS) sind(thetaS)]';   %(m/s) velocity of spacecraft 

dmin=0;

options = odeset('Events',@checkImpact,'RelTol', 1e-8);

%time constraints
ti=0; 
tf=10; %days
tf=tf*86400; %convert to seconds

if abs(x(1))>100 %check if in spacecraft's capabilities
    x(1)=100;
end

vMag=x(1);
vAng=x(2);

velS=velS+vMag*[cosd(vAng) sind(vAng)]'; %adjust spacecraft's initial velocity accordingly

X(7:8)=velS;
switch choice
    case 1
        [t,Y,te,~,~]=ode45(@trajectory,[ti tf],X,options);
        [impact,~,~] = checkImpact(t,Y(end,1:4));
        if impact==1
            f=sqrt((te-dmin)^2);
        else
            f=1e10.*sqrt((te-dmin)^2);
        end
        if isempty(f)
            f=1e10*t(end);
        end
    case 2
        [t,Y,~,~,~]=ode45(@trajectory,[ti tf],X,options);
        [impact,~,~] = checkImpact(t,Y(end,1:4));
        if impact==1
            f=sqrt((vMag-dmin)^2);
        else
            f=1e10.*sqrt((vMag-dmin)^2);
        end
end
end

