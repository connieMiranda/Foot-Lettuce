function [FseX, FseY, FesX, FesY, FmeX, FmeY, FemX, FemY, FsmX, FsmY, FmsX, FmsY] = calcF(Xs, Ys, Xm, Ym)
% CalcF takes the locations of the satellite and the moon relative to the
% earth and computes the magnitudes and directions of the net gravitational
% forces acting on the bodies

G=6.67408*10^-11;
mM=7.34767309e22;   %(kg) moon mass
mE=5.97219e24;      %(kg) earth mass
mS=28833;           %(kg) spacecraft mass

% distance between s/c and earth
dSE = sqrt((Xs)^2 + (Ys)^2);

% distance between moon and earth
dME = sqrt(Xm^2 + Ym^2);

% distance between s/c and moon
dSM = sqrt((Xs - Xm)^2 + (Ys - Ym)^2);

% compute forces
FseX = G*mS*mE*(Xs)/(dSE^3);
FseY = G*mS*mE*(Ys)/(dSE^3);
FesX = -FseX;
FesY = -FseY;

FmeX = G*mM*mE*(Xm)/(dME^3);
FmeY = G*mM*mE*(Ym)/(dME^3);
FemX = -FmeX;
FemY = -FmeY;

FsmX = G*mS*mM*(Xs - Xm)/(dSM^3);
FsmY = G*mS*mM*(Ys - Ym)/(dSM^3);
FmsX = -FsmX;
FmsY = -FsmY;
end

