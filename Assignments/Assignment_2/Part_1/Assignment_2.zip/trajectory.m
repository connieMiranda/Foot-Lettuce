function [dXdt] = trajectory(t,X)
%trajectory finds the path taken by the moon and spacecraft

%DO NOT ALTER THIS ONE, IT IS A CHECKPOINT TO START OVER FROM

mM=7.34767309e22;   %(kg) moon mass
%mE=5.97219e24;      %(kg) earth mass
mS=28833;           %(kg) spacecraft mass

xM=X(1);
yM=X(2);
xS=X(3);
yS=X(4);
vxM=X(5);
vyM=X(6);
vxS=X(7);
vyS=X(8);

% compute forces
[~, ~, FesX, FesY, ~, ~, FemX, FemY, FsmX, FsmY, FmsX, FmsY] = calcF(xS, yS, xM, yM);

% define acceleration
aSx = (FmsX + FesX)/mS;
aSy = (FmsY + FesY)/mS;

aMx = (FemX + FsmX)/mM;
aMy = (FemY + FsmY)/mM;

% build rate of change vector
dXdt = [vxM; vyM; vxS; vyS; aMx; aMy; aSx; aSy];
end