function [h] = maxH(r,Wp,Wd,MW)
%maxH find the maximum attainable height of a balloon given its key
%properties
%   r = radius (m)
%   Wp = payload weight (m)
%   Wd = dry weight (m)
%   MW = molecular weight

H=1e5; %maximum allowed computation height

W=totalWeight(r,Wp,Wd,MW);
h=0;
while h<H %capping how high comparison can be analyzed
Wa=airWeight(h,r);
if Wa<=W %is the displaced air wieght less than the balloon weight?
    break; %max weight found
else
    h=h+10; %increase height
end
end
if h>=H
    error('Maximum computation height has been reached');
end
end

