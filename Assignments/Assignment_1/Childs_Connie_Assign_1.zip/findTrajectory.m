function [x,y] = findTrajectory(x0,y0,t0,g,theta,v0)
%findTrajectory Calculates the trajectory of a projectile
%   x0 = Initial horizontal position
%   y0 = Initial vertical position
%   t0 = Initial time
%   g = gravity acceleration
%   theta = launch angle (degrees)
%   v0 = initial speed
%Output are the x and y positions with time
%designed to work with question_1.m

%Finding time vector
tf=(sqrt(2*g*y0+(v0*sind(theta))^2)+g*t0+v0*sind(theta))/g; %finding time of impact
t=linspace(t0,tf); %time vector

x=x0+v0.*cosd(theta).*t; %finding horizontal vector
y=y0+v0.*sind(theta).*t-1/2.*g.*t.^2; %finding vertical vector
end