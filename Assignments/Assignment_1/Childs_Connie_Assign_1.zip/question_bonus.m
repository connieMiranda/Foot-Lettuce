function [S] = bonus(N,M)
%bonus randomly assigns students into pairs for group assignments, with no
%duplicates. A single group of 3 is made if the number of students is odd
%   N = number of students
%   M = number of paired assignments
%Output is a table of groups for each assignment

s=cell(M,1); %allocate assignment list
if mod(N,2)~=0 %if the number of students is odd, enter this region
    topLabels=cell(1,3*M); %allocate labelling row
    S=zeros(floor(N/2)+1,3*M); %allocate grouping sheet
    for i=1:M %for each assignment
        s{i}=zeros(floor(N/2),3); %allocate size of a singular asignment sheet
    end
    for i=1:M %for each assignment
        for y=1:floor(N/2) %for each student slot for the first half of students
            t=0; %a student has not yet been found
            while t==0 %while a student has not been found
                a=randi([1 N],1,1); %pick a student
                if all(s{i}(:,1)~=a) %if this student was not previously picked
                    s{i}(y,1)=a; %put them in this slot
                    t=1; %a student has been found
                end
            end
        end
        for j=1:floor(N/2) %for each student slot for the second half of students
            t=0; %a student has not yet been found
            while t==0 %while a student has not been found
                a=randi([1 N],1,1); %pick a student
                if all(all(s{i}~=a)==1) && i==1 %if this student was not previously picked
                    s{i}(j,2)=a; %put them in this slot
                    t=1; %a student has been found
                elseif all(all(s{i}~=a)==1) && a~=s{i-1}(j,2) %if this student was not previously picked and not ever picked for this specific slot
                    s{i}(j,2)=a; %put them in this slot
                    t=1; %a student has been found
                end
            end
        end
        t=0; %the last student has been found
        while t==0 %whle the last student has been found
            a=randi([1 N],1,1); %pick a student
            if all(all(s{i}~=a)==1) && i==1 %if this student was not previously picked
                s{i}(1,3)=a; %put them in this slot
                t=1; %a student has been found
            elseif all(all(s{i}~=a)==1) && a~=s{i-1}(1,3) %if this student was not previously picked and not ever picked for this specific slot
                s{i}(1,3)=a; %put them in this slot
                t=1; %a student has been found
            end
        end
    s{i}(2:end,3)=nan; %void the empty space in the group sheet
    topLabels{3*i-2}=sprintf('Assignment_%d_Student_A',i); %label Student A's row 
    topLabels{3*i-1}=sprintf('Assignment_%d_Student_B',i); %label Student B's row 
    topLabels{3*i}=sprintf('Assignment_%d_Student_C',i);   %label Student C's row 
    S(2:end,(3*i-2):(3*i))=s{i}; %add this singular assignment sheet into the group sheet
    end
    S=num2cell(S); %convert group sheet into a cell
    S(1,:)=topLabels; %add in column labels
else %if the number of students is even, enter this region 
    topLabels=cell(1,2*M); %allocate labelling row
    S=zeros(N/2+1,2*M); %allocate grouping sheet
    for i=1:M %for each assignment
        s{i}=zeros(N/2,2); %allocate size of a singular asignment sheet
    end
    for i=1:M %for each assignment
        for y=1:N/2 %for each student slot for the first half of students
            t=0; %a student has not been found
            while t==0 %while a student has not been found
                a=randi([1 N],1,1); %pick a student
                if all(s{i}(:,1)~=a) %if this student has not been previously picked
                    s{i}(y,1)=a; %add them into this slot
                    t=1; %a student has been found
                end
            end
        end
        for j=1:N/2 %for each student slot for the second half of students
            t=0; %a student has not been found
            while t==0 %while a student has not been found
                a=randi([1 N],1,1); %pick a student
                if all(all(s{i}~=a)==1) && i==1 %if this student was not previously picked
                    s{i}(j,2)=a; %add them into this slot
                    t=1; %a student has been found
                elseif all(all(s{i}~=a)==1) && a~=s{i-1}(j,2) %if this student was not previously picked and not ever picked for this specific slot
                    s{i}(j,2)=a; %add them into this slot
                    t=1; %a student has been found
                end
            end
        end
    topLabels{2*i-1}=sprintf('Assignment_%d_Student_A',i); %label Student A's row
    topLabels{2*i}=sprintf('Assignment_%d_Student_B',i);   %label Student B's row
    S(2:end,(2*i-1):(2*i))=s{i}; %add this singular assignment sheet into the group sheet
    end
    S=num2cell(S); %convert group sheet into a cell
    S(1,:)=topLabels; %add in column labels
end
end