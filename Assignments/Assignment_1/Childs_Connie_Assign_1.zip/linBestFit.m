function [m,b] = linBestFit(x,y)
%linBestFit Computes a linear line of best fit by method of least squares
%   x = input of function
%   y = outout of function
%Output:
%   m = slope
%   b = vertical displacement

%checking for same length
N=length(x);
if N~=length(y)
    error('Input vectors are different lengths');
end

%Finding equation components
A=0; %allocations 
B=0;
C=0;
D=0;
for i=1:N %manual summations
    A=A+x(i);
    B=B+y(i);
    C=C+x(i)*y(i);
    D=D+x(i)^2;
end

%Finding m and b
m=(A*B-N*C)/(A^2-N*D);
b=(A*C-B*D)/(A^2-N*D);
end
