%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Author: Connie Childs
%Created: Jan, 22, 2018
%This program plots a best fit plot on top of the original plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%housekeeping
clear variables
close all

%making vectors
alpha=[-5 -2 0 2 3 5 7 9 11];
cl=[-.008 -.003 .001 .005 .007 .006 .009 .0145 .019];

%finding linear best fit
[m,b]=linBestFit(alpha,cl);

%Plotting
figure(1)%generate figure
grid on; grid minor; hold on; %switching on settings
plot(alpha,cl); %plot
plot(alpha,m*alpha+b);
ylabel('Height (m)'); %labels
xlabel('Distance (m)');
title('Trajectory Plot');
legend('Data','Best Fit','location','northwest');