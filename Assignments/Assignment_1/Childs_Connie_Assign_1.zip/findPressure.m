function [P] = findPressure(h,T)
%findTPressure finds the pressure of air given a height in altitude
%   h = height (m)
%   T = Temperature (�C)
%Output is Pressure (kPa)

%Different formulas used based on height
if 0<=h && h<11000
    P=101.29*((T+273.15)/288.08)^5.256;
elseif 11000<=h && h<25000
    P=22.65*exp(1.73-.000157*h);
elseif 25000<=h
    P=2.488*((T+273.15)/216.6)^-11.388;
else
    error('Height is out of range');
end
end