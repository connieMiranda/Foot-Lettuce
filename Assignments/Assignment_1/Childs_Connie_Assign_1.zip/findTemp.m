function [T] = findTemp(h)
%findTemp finds the temperature of air given a height in altitude
%   h = height (m)
%Output is Temperature (�C)

%Different formulas used based on height
if 0<=h && h<11000
    T=15.04-.00649*h;
elseif 11000<=h && h<25000
    T=-56.46;
elseif 25000<=h
    T=-131.21+.00299*h;
else
    error('Height is out of range');
end
end

