function [Wa] = airWeight(h,r)
%airWeight finds the density of air given a height in altitude
%   h = height (m)
%   r = balloon radius (m)
%Output is air wieght (kg/m^3)

T=findTemp(h); %getting pressure
P=findPressure(h,T); %getting temperature
rho=P/(.2869*(T+273.15)); %finding density
Wa=4*pi*rho*r^3/3; %finding air weight
end