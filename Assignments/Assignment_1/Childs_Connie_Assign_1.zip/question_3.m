%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Author: Connie Childs
%Created: Jan, 22, 2018
%This program finds the maximum attainable altitude of a balloon
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%balloon properties
r=3.5; %radius (m)
Wp=5; %payload weight (kg)
Wd=.6; %dry weight (kg)
MW=4.02; %lifting gas molecular weight

[h] = maxH(r,Wp,Wd,MW);

fprintf('The maximum balloon height is: %.0f meters.\n',h);