—————
All .m files titled in the format “question_x.m” are executable script files, and give the answers to the questions posed asked by the corresponding question number.
—
All other .m files not following this title format are functions, and get called by one or more of the script files.
—————