function [W] = totalWeight(r,Wp,Wd,MW)
%totalWeight Finds the total weight of a balloon (kg)
%   r = balloon radius (m)
%   Wp = payload weight (kg)
%   Wd = dry weight of balloon (kg)
%   MW = molecular weight of gas

%finding gas wieght
rho0=1.225; %sealevel air density (kg/m^3)
Wg=4*pi*rho0*r^3/3*MW/28.966;

%sum up weights
W=Wg+Wp+Wd;
end

