%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Author: Connie Childs
%Created: Jan, 22, 2018
%This program plots the trajectory of a projectile
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%housekeeping
clear variables
close all

%Initial conditions
theta=30; %degrees
x0=0;
y0=0;
t0=0; %initial time
v0=25; %m/s
g=9.81; %m/s^2

%Calculation
[x,y]=findTrajectory(x0,y0,t0,g,theta,v0);

%Plotting
figure(1)%generate figure
grid on; grid minor; hold on; %switching on settings
plot(x,y); %plot
ylabel('Height (m)'); %labels
xlabel('Distance (m)');
title('Trajectory Plot');
legend('Projectile Path');